package com.example.myapplication.provider;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName = "car")
public class Car implements Serializable {

    @PrimaryKey(autoGenerate=true)
    @NonNull
    @ColumnInfo(name="carId")
    private int car_id;

    @ColumnInfo(name="carMaker")
    private String carMaker;

    @ColumnInfo(name="carModel")
    private String carModel;

    @ColumnInfo(name="carYear")
    private int carYear;

    @ColumnInfo(name="carColor")
    private String carColor;

    @ColumnInfo(name="carSeats")
    private int carSeats;

    @ColumnInfo(name="car_price")
    private int car_price;


    public Car(String carMaker, String carModel, int carYear, String carColor, int carSeats, int car_price) {
        this.carMaker = carMaker;
        this.carModel = carModel;
        this.carYear = carYear;
        this.carColor = carColor;
        this.carSeats = carSeats;
        this.car_price = car_price;
    }

    public String getCarMaker() {
        return carMaker;
    }

    public void setCarMaker(String carMaker) {
        this.carMaker = carMaker;
    }

    public String getCarModel() {
        return carModel;
    }

    public void setCarModel(String carModel) {
        this.carModel = carModel;
    }

    public String getCarColor() {
        return carColor;
    }

    public void setCarColor(String carColor) {
        this.carColor = carColor;
    }

    public int getCarSeats() {
        return carSeats;
    }

    public void setCarSeats(int carSeats) {
        this.carSeats = carSeats;
    }

    public int getCarYear() {
        return carYear;
    }

    public void setCarYear(int carYear) {
        this.carYear = carYear;
    }

    public int getCar_id() {
        return car_id;
    }

    public void setCar_id(int car_id) {
        this.car_id = car_id;
    }

    public int getCar_price() {
        return car_price;
    }

    public void setCar_price(int car_price) {
        this.car_price = car_price;
    }
}
